ShowerCore configurable pools - both builds

Install the one matching your Minecraft version and loader:
- 1.21.1-NeoForge: Java 21, NeoForge, Hot Bath 4.1.2.
- 1.20.1-Forge: Java 17, Forge, Hot Bath 4.1.2.

This archive contains the two ShowerCore JARs. The separate version-specific preview packages include Hot Bath as well.

Use the reusable pool planner in the air to choose material and shape, then preview and confirm on the ground. Empty-hand click to sit; sneak to stand up. Use the planner on an existing pool to change its finish. Dimensions: 3-16 blocks per side, one-block height.
