# ShowerCore configurable pools preview

Choose the package for your Minecraft version. Each ZIP includes ShowerCore and the tested Hot Bath 4.1.2 dependency. Place the two JARs in the instance's mods folder, replacing older copies of those same mods. Use the matching package on the client and server.

- Minecraft 1.21.1: NeoForge; tested with NeoForge 21.1.215 and Java 21.
- Minecraft 1.20.1: Forge; tested with Forge 47.3.0 and Java 17.

Craft the reusable planner from paper, a stick and an iron ingot. Right-click in the air, put a block from your inventory in the material slot, and choose shape, dimensions and side/top texture. Click the ground for a preview, then click inside again to build. Fit room uses two corners and a final confirmation.

Use buckets on the pool. Empty-hand click inside or on the rim to sit; sneak to stand up. Use the planner on an existing pool to change all its material faces. A material change returns the previously paid material; side/top texture changes are free. Showers and both duck skins work with the pool.

Dimensions are 3-16 blocks per side, with one-block depth. Changing an existing pool's size or shape requires dismantling and rebuilding. Breaking a member returns paid construction materials once; liquid is not recovered into the planner.

## 使用说明

按 Minecraft 版本选择对应 ZIP，将其中两个 JAR 放进 mods 目录并替换旧版同名模组，客户端和服务器保持一致。

用纸、木棍和铁锭合成规划器。空中右键打开菜单，把背包里的材质方块放入样本槽，再选择矩形、圆角或圆形及尺寸。点击地面显示预览，再点击范围内确认建造；房间模式选择两个角后再确认。

水桶可在任一位置加水。空手右键池内或池沿坐下，按潜行键起身。规划器右键已建浴池可更换整池材质，返还原先付过的材料，同材质切换侧面／顶面纹理免费。支持喷头和两种小黄鸭。

尺寸范围为每边 3–16 格，固定一格高度。改变大小或形状需要拆除重建；拆除只返还建材，规划器不回收池内液体。
